library("PipeHelpR")
library("testthat")

test_that("testable objects can be instanciated", {
  expect_no_error({
    obj1 = letters
    obj2 = setDimnames(array(1:24, c(2,3,4)), list(letters[1:2],letters[3:5],letters[6:9]))
    obj3 = setColnames(as.data.frame(matrix(1:9, 3)), c("a","b","c"))
    obj4 = setNames(lapply(1:5, I), letters[22:26])
  })
})

test_that("index() works", {
  expect_equal(index(obj1, 10:5), letters[10:5])
  expect_equal(index(obj1, 5:10, neg=T), letters[-(5:10)])
  expect_equal(index(obj1, c(rep(F,4), rep(T,6), rep(F,16))), letters[5:10])
  expect_equal(index(obj2, list(1,3,2)), obj2[1,3,2])
  expect_equal(index(obj2, list("b", c(F,T,T), 1), neg=c(T,F,T)), obj2[1,2:3,2:4])
  expect_equal(index(obj3, list(2, 3), neg=c(T,F)), obj3[-2,3])
  expect_equal(index(obj4, 2:3), obj4[2:3])
})

test_that("whichInv() works", {
  expect_equal(whichInv(3:5, len=8), c(rep(F,2), rep(T,3), rep(F,3)))
})

test_that("do() works", {
  expect_equal(do(1:4, sum), 10)
})
